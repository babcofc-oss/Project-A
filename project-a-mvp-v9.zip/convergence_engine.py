"""
Project A v5 — Multi-source convergence engine

Purpose:
Normalize heterogeneous public-disclosure events into one evidence model,
resolve them around an entity, deduplicate, and rank advisor opportunities.

Facts and inferences are intentionally stored separately.
"""
from dataclasses import dataclass, asdict
from datetime import date, datetime
from hashlib import sha256
from typing import Optional
import re

SOURCE_WEIGHTS = {
    "FORM4": 24,
    "SCHEDULE13D": 26,
    "SCHEDULE13G": 18,
    "FORM8K_MA": 30,
    "FORMADV": 10,
    "STATE_BUSINESS": 12,
    "OTHER_PRIMARY": 10,
}

@dataclass
class Evidence:
    source_type: str
    source_url: str
    filed_date: str
    entity_name: str
    person_name: Optional[str] = None
    cik: Optional[str] = None
    event_type: str = ""
    disclosed_value: Optional[float] = None
    ownership_pct: Optional[float] = None
    shares: Optional[float] = None
    location: Optional[str] = None
    primary_source: bool = True
    planned_transaction: bool = False
    fact_summary: str = ""
    raw_id: Optional[str] = None

def canonical_name(s: Optional[str]) -> str:
    if not s:
        return ""
    s = re.sub(r"[^A-Za-z0-9 ]+", " ", s).lower()
    return " ".join(s.split())

def evidence_key(e: Evidence) -> str:
    # accession/raw id wins; otherwise deterministic event fingerprint
    if e.raw_id:
        return f"{e.source_type}:{e.raw_id}"
    base = "|".join([
        e.source_type, canonical_name(e.entity_name),
        canonical_name(e.person_name), e.filed_date, e.event_type,
        str(e.disclosed_value or ""), str(e.shares or "")
    ])
    return sha256(base.encode()).hexdigest()[:24]

def entity_key(e: Evidence) -> str:
    # CIK is strongest issuer identity. Person is included when prospect is a person.
    if e.person_name and e.cik:
        return f"person:{canonical_name(e.person_name)}:issuer:{e.cik}"
    if e.cik:
        return f"issuer:{e.cik}"
    if e.person_name:
        return f"person:{canonical_name(e.person_name)}"
    return f"entity:{canonical_name(e.entity_name)}"

def recency_points(filed_date: str, as_of: Optional[date] = None) -> int:
    as_of = as_of or date.today()
    try:
        d = datetime.strptime(filed_date, "%Y-%m-%d").date()
    except Exception:
        return 0
    days = max(0, (as_of - d).days)
    if days <= 7: return 18
    if days <= 30: return 14
    if days <= 90: return 9
    if days <= 180: return 4
    return 0

def magnitude_points(v: Optional[float]) -> int:
    if not v: return 0
    if v >= 10_000_000: return 24
    if v >= 2_000_000: return 20
    if v >= 500_000: return 15
    if v >= 100_000: return 9
    return 4

def converge(events: list[Evidence], as_of: Optional[date] = None):
    # exact-event dedupe
    unique = {}
    for e in events:
        unique[evidence_key(e)] = e

    groups = {}
    for e in unique.values():
        groups.setdefault(entity_key(e), []).append(e)

    results = []
    for key, evs in groups.items():
        source_classes = set(e.source_type for e in evs)
        primary_count = sum(1 for e in evs if e.primary_source)
        disclosed = sum(e.disclosed_value or 0 for e in evs)

        source_score = min(38, sum(SOURCE_WEIGHTS.get(s, 6) for s in source_classes))
        recency = max((recency_points(e.filed_date, as_of) for e in evs), default=0)
        magnitude = magnitude_points(disclosed)
        convergence_bonus = min(18, max(0, len(source_classes)-1) * 9)
        evidence_bonus = min(8, primary_count * 2)
        planned_penalty = 8 if evs and all(e.planned_transaction for e in evs) else 0

        score = max(0, min(100,
            10 + source_score + recency + magnitude +
            convergence_bonus + evidence_bonus - planned_penalty
        ))

        facts = [e.fact_summary for e in evs if e.fact_summary]
        results.append({
            "entity_key": key,
            "person": next((e.person_name for e in evs if e.person_name), None),
            "company": evs[0].entity_name,
            "score": score,
            "source_count": len(source_classes),
            "evidence_count": len(evs),
            "sources": sorted(source_classes),
            "disclosed_value_total": round(disclosed, 2) if disclosed else None,
            "latest_event": max((e.filed_date for e in evs), default=None),
            "confidence": "High" if primary_count >= 2 or len(source_classes) >= 2 else "Medium",
            "facts": facts,
            "evidence": [asdict(e) | {"evidence_key": evidence_key(e)} for e in
                         sorted(evs, key=lambda x:x.filed_date, reverse=True)],
            "model_inference": (
                "Multiple independent public-disclosure classes converge on this prospect."
                if len(source_classes) >= 2 else
                "Single-source public signal; additional corroboration would strengthen priority."
            )
        })
    return sorted(results, key=lambda x:(x["score"], x["latest_event"] or ""), reverse=True)
