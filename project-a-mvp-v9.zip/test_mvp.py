
import json, os, subprocess, sys, tempfile
from pathlib import Path
import database
import seed_real_data

def run():
    xs=database.get_opportunities()
    assert len(xs)==3, xs
    li=xs[0]
    assert li["person_name"]=="David H. Li"
    assert li["event_count"]==2
    assert round(li["disclosed_value"],2)==761750.00
    ca=[x for x in xs if x["person_name"]=="Chad Anderson"][0]
    assert ca["event_count"]==2
    assert ca["disclosed_value"]>289000
    gr=[x for x in xs if x["person_name"]=="Jeffrey A. Graves"][0]
    assert gr["disclosed_value"] is None, "Tax withholding must not be counted as liquidity"
    before=li["watchlisted"]
    after=database.toggle_watchlist(li["id"])
    assert after != before
    database.toggle_watchlist(li["id"])
    h=database.health()
    assert h["events"]==5
    assert h["evidence"]>=10
    print(json.dumps({"status":"PASS","opportunities":h["opportunities"],"events":h["events"],"evidence":h["evidence"]},indent=2))
if __name__=="__main__":run()
