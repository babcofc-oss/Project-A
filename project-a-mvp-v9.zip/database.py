
import sqlite3, json
from pathlib import Path

DB = Path(__file__).with_name("project_a.db")

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS prospects(
 id INTEGER PRIMARY KEY,
 person_name TEXT NOT NULL,
 role TEXT,
 company TEXT NOT NULL,
 issuer_cik TEXT,
 category TEXT NOT NULL,
 city TEXT,
 state TEXT,
 lat REAL,
 lon REAL,
 distance_miles REAL,
 score INTEGER NOT NULL,
 evidence_quality TEXT,
 advisor_relevance TEXT,
 primary_need TEXT,
 secondary_need TEXT,
 why_now TEXT,
 model_inference TEXT,
 tags_json TEXT NOT NULL DEFAULT '[]',
 score_components_json TEXT NOT NULL DEFAULT '{}',
 watchlisted INTEGER NOT NULL DEFAULT 0,
 scoring_version TEXT NOT NULL DEFAULT 'v1'
);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY,
 prospect_id INTEGER NOT NULL REFERENCES prospects(id) ON DELETE CASCADE,
 accession TEXT NOT NULL,
 form_type TEXT NOT NULL,
 event_date TEXT,
 event_type TEXT NOT NULL,
 shares REAL,
 price REAL,
 disclosed_value REAL,
 remaining_shares REAL,
 planned_transaction INTEGER NOT NULL DEFAULT 0,
 liquidity_class TEXT NOT NULL,
 fact_summary TEXT NOT NULL,
 source_url TEXT NOT NULL,
 UNIQUE(accession,event_type,fact_summary)
);
CREATE TABLE IF NOT EXISTS evidence(
 id INTEGER PRIMARY KEY,
 prospect_id INTEGER NOT NULL REFERENCES prospects(id) ON DELETE CASCADE,
 event_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
 label TEXT NOT NULL,
 assertion_class TEXT NOT NULL,
 summary TEXT NOT NULL,
 source_url TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_prospect ON events(prospect_id);
"""

def connect():
    cx=sqlite3.connect(DB)
    cx.row_factory=sqlite3.Row
    cx.executescript(SCHEMA)
    return cx

def prospect_payload(cx, row):
    ev=[dict(x) for x in cx.execute("SELECT * FROM events WHERE prospect_id=? ORDER BY event_date DESC,id DESC",(row["id"],))]
    ed=[dict(x) for x in cx.execute("SELECT label,assertion_class,summary,source_url AS url FROM evidence WHERE prospect_id=? ORDER BY id",(row["id"],))]
    verified=[x["fact_summary"] for x in ev]
    disclosed=sum((x["disclosed_value"] or 0) for x in ev if x["liquidity_class"]=="LIQUIDITY")
    latest=ev[0]["event_date"] if ev else None
    summary=ev[0]["fact_summary"] if ev else "No event"
    return {
      **dict(row),
      "watchlisted":bool(row["watchlisted"]),
      "tags":json.loads(row["tags_json"] or "[]"),
      "score_components":json.loads(row["score_components_json"] or "{}"),
      "event_count":len(ev),
      "events":ev,
      "evidence":ed,
      "verified_facts":verified,
      "disclosed_value":disclosed or None,
      "last_event_date":latest,
      "event_summary":summary,
      "recency_days":None,
    }

def get_opportunities():
    with connect() as cx:
        rows=cx.execute("SELECT * FROM prospects ORDER BY score DESC,person_name").fetchall()
        return [prospect_payload(cx,r) for r in rows]

def get_opportunity(pid):
    with connect() as cx:
        row=cx.execute("SELECT * FROM prospects WHERE id=?",(pid,)).fetchone()
        return prospect_payload(cx,row) if row else None

def toggle_watchlist(pid):
    with connect() as cx:
        row=cx.execute("SELECT watchlisted FROM prospects WHERE id=?",(pid,)).fetchone()
        if not row:return None
        new=0 if row["watchlisted"] else 1
        cx.execute("UPDATE prospects SET watchlisted=? WHERE id=?",(new,pid));cx.commit()
        return bool(new)

def health():
    with connect() as cx:
        return {
          "status":"LIVE LOCAL MVP",
          "opportunities":cx.execute("SELECT COUNT(*) FROM prospects").fetchone()[0],
          "events":cx.execute("SELECT COUNT(*) FROM events").fetchone()[0],
          "evidence":cx.execute("SELECT COUNT(*) FROM evidence").fetchone()[0],
          "database":str(DB)
        }
