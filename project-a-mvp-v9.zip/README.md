# Project A v9 — Runnable Advisor-Intelligence MVP

This is the first Project A build where the approved v8 dashboard reads prospect intelligence from a persistent database/API instead of a hard-coded JavaScript array.

## Run

```bash
python seed_real_data.py
python app_server.py
```

Open `http://127.0.0.1:8787`.

## Shipped

- Approved v8 dashboard preserved
- SQLite persistence
- `/api/opportunities`
- `/api/opportunities/:id`
- `/api/opportunities/:id/brief`
- persistent watchlist toggle
- retained source URLs
- evidence ledger with assertion classes
- person-level timelines / duplicate filing clustering
- non-liquidity Form 4 classification
- real verified seed records only (no synthetic prospect names)
- advisor brief generated from stored evidence
- existing SEC ingestion/convergence code carried forward

## Real seed data

- David H. Li / Ingevity — two Aug. 2026 open-market sales clustered into one timeline
- Chad Anderson / Blackbaud — June + September 2026 sales clustered into one timeline
- Jeffrey A. Graves / 3D Systems — Form 4 code F retained as a negative/non-liquidity example

## Data-integrity behavior

Only events classified as `LIQUIDITY` contribute to the displayed disclosed-liquidity total. Tax-withholding code F does not.

## Deployment blocker

The connected GitHub integration can edit existing repositories but currently exposes no repository-creation action. The connected Vercel team has no Git-linked Project A repository and the available deployment action requires an accessible repository. This package is ready to push once a `project-a` repository exists.
