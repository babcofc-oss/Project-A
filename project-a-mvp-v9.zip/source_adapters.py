"""
Source adapter contracts for Project A.

These adapters deliberately output Evidence objects rather than prospect claims.
Production fetchers/parsers can be added behind these functions without changing
the convergence/scoring layer.
"""
from convergence_engine import Evidence

def form4_event(*, issuer, cik, person, filed_date, source_url, value=None,
                shares=None, planned=False, raw_id=None, summary=""):
    return Evidence("FORM4", source_url, filed_date, issuer, person, cik,
                    "insider-ownership-change", value, None, shares, None,
                    True, planned, summary, raw_id)

def schedule13_event(*, form, issuer, cik, holder, filed_date, source_url,
                     ownership_pct=None, value=None, raw_id=None, summary=""):
    st = "SCHEDULE13D" if "13D" in form.upper() else "SCHEDULE13G"
    return Evidence(st, source_url, filed_date, issuer, holder, cik,
                    "beneficial-ownership", value, ownership_pct, None, None,
                    True, False, summary, raw_id)

def form8k_ma_event(*, issuer, cik, filed_date, source_url, value=None,
                    raw_id=None, summary=""):
    return Evidence("FORM8K_MA", source_url, filed_date, issuer, None, cik,
                    "acquisition-disposition", value, None, None, None,
                    True, False, summary, raw_id)

def formadv_event(*, adviser, filed_date, source_url, location=None,
                  value=None, raw_id=None, summary=""):
    # value may represent a directly disclosed regulatory-AUM field only.
    return Evidence("FORMADV", source_url, filed_date, adviser, None, None,
                    "adviser-profile", value, None, None, location,
                    True, False, summary, raw_id)

def state_business_event(*, entity, filed_date, source_url, location=None,
                         raw_id=None, summary=""):
    return Evidence("STATE_BUSINESS", source_url, filed_date, entity, None, None,
                    "business-record-change", None, None, None, location,
                    True, False, summary, raw_id)
