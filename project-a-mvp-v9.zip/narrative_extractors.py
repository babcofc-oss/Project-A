"""
Narrative extraction helpers for Project A v7.
Conservative regex-based extraction: a candidate becomes a fact only when
the source text explicitly supports it. Ambiguous values remain null.
"""
import re
from html import unescape

def clean_html(s):
    s=re.sub(r"(?is)<script.*?</script>|<style.*?</style>"," ",s)
    s=re.sub(r"(?s)<[^>]+>"," ",s)
    return re.sub(r"\s+"," ",unescape(s)).strip()

def parse_money(s):
    m=re.search(r"\$\s*([\d,.]+)\s*(billion|million|thousand)?",s,re.I)
    if not m:return None
    n=float(m.group(1).replace(",",""))
    unit=(m.group(2) or "").lower()
    return n*({"billion":1e9,"million":1e6,"thousand":1e3}.get(unit,1))

def extract_8k_item_201(html):
    text=clean_html(html)
    m=re.search(r"Item\s+2\.01\b(.*?)(?=Item\s+\d+\.\d+|SIGNATURES|$)",text,re.I)
    if not m:return None
    section=m.group(1)[:12000]
    return {"item":"2.01","disclosed_value_candidate":parse_money(section),
            "excerpt":section[:700]}

def extract_13_ownership(html):
    text=clean_html(html)
    # Conservative common-language percentage extraction.
    pats=[r"percent(?:age)?\s+of\s+class[^0-9]{0,80}([\d.]+)\s*%",
          r"([\d.]+)\s*%\s+of\s+(?:the\s+)?(?:outstanding\s+)?(?:shares|class)"]
    pct=None
    for p in pats:
        m=re.search(p,text,re.I)
        if m:
            try:pct=float(m.group(1));break
            except:pass
    shares=None
    m=re.search(r"aggregate\s+amount\s+beneficially\s+owned[^0-9]{0,80}([\d,]+)",text,re.I)
    if m:
        try:shares=float(m.group(1).replace(",",""))
        except:pass
    return {"ownership_pct_candidate":pct,"shares_candidate":shares}
