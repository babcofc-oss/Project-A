"""
Project A v7 — geographic/entity enrichment.

No location is invented. Resolution carries provenance and confidence.
Production geocoding should use a licensed geocoder or authoritative public
address source and cache results.
"""
from dataclasses import dataclass, asdict
from math import radians, sin, cos, asin, sqrt
from typing import Optional

@dataclass
class Location:
    city: Optional[str]=None
    state: Optional[str]=None
    postal_code: Optional[str]=None
    lat: Optional[float]=None
    lon: Optional[float]=None
    source: Optional[str]=None
    confidence: str="Unknown"

def haversine_miles(a_lat,a_lon,b_lat,b_lon):
    if None in (a_lat,a_lon,b_lat,b_lon): return None
    R=3958.7613
    p1,p2=radians(a_lat),radians(b_lat)
    dp=radians(b_lat-a_lat); dl=radians(b_lon-a_lon)
    h=sin(dp/2)**2+cos(p1)*cos(p2)*sin(dl/2)**2
    return 2*R*asin(sqrt(h))

def choose_location(candidates):
    """Prefer authoritative/current candidates; never average addresses."""
    rank={"FORM4_ISSUER_ADDRESS":80,"SEC_SUBMISSION_ADDRESS":75,
          "FORMADV_ADDRESS":90,"STATE_BUSINESS_ADDRESS":85,
          "LICENSED_GEOCODER":70,"OTHER":20}
    usable=[x for x in candidates if x]
    if not usable:return Location()
    usable.sort(key=lambda x:rank.get(x.source or "OTHER",20),reverse=True)
    return usable[0]

def territory_enrich(signal, location:Location, center_lat=None, center_lon=None):
    x=dict(signal)
    x["location"]=asdict(location)
    x["distance_miles"]=haversine_miles(center_lat,center_lon,location.lat,location.lon)
    return x

def territory_filter(signals, radius_miles=None, min_score=0):
    xs=[x for x in signals if x.get("score",0)>=min_score]
    if radius_miles is not None:
        xs=[x for x in xs if x.get("distance_miles") is not None and x["distance_miles"]<=radius_miles]
    return sorted(xs,key=lambda x:(x.get("score",0),-(x.get("distance_miles") or 99999)),reverse=True)
