
import json
from database import connect

records=[
{
 "id":1,"person":"David H. Li","role":"President & CEO","company":"Ingevity","cik":"1436880","category":"Insider",
 "city":"North Charleston","state":"SC","lat":32.8546,"lon":-79.9748,"distance":7.0,"score":92,
 "quality":"High","relevance":"Very High","primary":"Concentrated equity / diversification","secondary":"Tax coordination",
 "why":"Two disclosed open-market sales represent a meaningful monetization event while the same filing reports a substantial remaining issuer-stock position.",
 "inference":"Potential concentrated-equity, diversification and tax-planning opportunity. Total wealth, outside assets and the current disposition of sale proceeds are unknown.",
 "tags":["INSIDER SALE","FORM 4","10b5-1","VERIFIED"],
 "parts":{"event_magnitude":21,"recency":17,"evidence_quality":20,"advisor_relevance":19,"identity_confidence":10,"convergence":5},
 "events":[
  {"accession":"0001436880-26-000006","date":"2026-08-12","type":"OPEN_MARKET_SALE","shares":5000,"price":76.62,"value":383100,"remaining":135636,"planned":1,"liq":"LIQUIDITY","fact":"SEC Form 4 reports a sale of 5,000 NGVT shares at a reported weighted-average price of $76.62.","url":"https://www.sec.gov/Archives/edgar/data/1436880/000143688026000006/xslF345X06/wk-form4_1786741576.xml"},
  {"accession":"0001436880-26-000006","date":"2026-08-13","type":"OPEN_MARKET_SALE","shares":5000,"price":75.73,"value":378650,"remaining":130636,"planned":1,"liq":"LIQUIDITY","fact":"The same Form 4 reports a second sale of 5,000 NGVT shares at a reported weighted-average price of $75.73 and 130,636 shares beneficially owned after the transaction.","url":"https://www.sec.gov/Archives/edgar/data/1436880/000143688026000006/xslF345X06/wk-form4_1786741576.xml"}
 ]
},
{
 "id":2,"person":"Chad Anderson","role":"EVP & CFO","company":"Blackbaud","cik":"1280058","category":"Insider",
 "city":"Charleston","state":"SC","lat":32.7765,"lon":-79.9311,"distance":0.0,"score":84,
 "quality":"High","relevance":"High","primary":"Executive equity planning","secondary":"Diversification / tax coordination",
 "why":"Two separate monetization events are clustered into one executive timeline instead of being presented as duplicate prospects. The planned-sale evidence reduces urgency rather than erasing the planning signal.",
 "inference":"Repeated issuer-stock monetization may create an equity-planning conversation. Project A does not infer total net worth or outside brokerage assets.",
 "tags":["INSIDER SALE","REPEATED EVENT","10b5-1","VERIFIED"],
 "parts":{"event_magnitude":18,"recency":16,"evidence_quality":20,"advisor_relevance":17,"identity_confidence":10,"convergence":3},
 "events":[
  {"accession":"0001492840-26-000014","date":"2026-09-01","type":"OPEN_MARKET_SALE","shares":2000,"price":47.56,"value":95120,"remaining":59883,"planned":0,"liq":"LIQUIDITY","fact":"SEC Form 4 reports a sale of 2,000 BLKB shares at $47.56 and 59,883 shares directly beneficially owned after the transaction.","url":"https://www.sec.gov/Archives/edgar/data/1280058/000149284026000014/xslF345X06/wk-form4_1788380230.xml"},
  {"accession":"0001492840-26-000010","date":"2026-06-01","type":"OPEN_MARKET_SALE","shares":6205,"price":31.31,"value":194273.55,"remaining":62869,"planned":1,"liq":"LIQUIDITY","fact":"An earlier SEC Form 4 reports 6,205 BLKB shares sold at $31.31 and states that the sale was effected under a Rule 10b5-1 trading plan.","url":"https://www.sec.gov/Archives/edgar/data/1280058/000149284026000010/xslF345X06/wk-form4_1780519502.xml"}
 ]
},
{
 "id":3,"person":"Jeffrey A. Graves","role":"President & CEO","company":"3D Systems","cik":"910638","category":"Executive",
 "city":"Rock Hill","state":"SC","lat":34.9249,"lon":-81.0251,"distance":145.0,"score":38,
 "quality":"High","relevance":"Low","primary":"Monitor only","secondary":"No liquidity inference",
 "why":"This event is intentionally suppressed as a prospecting trigger because transaction code F reflects shares used to satisfy tax or exercise-price obligations rather than a normal open-market liquidity event.",
 "inference":"Low-priority monitoring record. A naive Form 4 scraper could incorrectly treat the reported dollar equivalent as investable liquidity; Project A does not.",
 "tags":["FORM 4","TAX WITHHOLDING","NEGATIVE SIGNAL","VERIFIED"],
 "parts":{"event_magnitude":4,"recency":16,"evidence_quality":20,"advisor_relevance":0,"identity_confidence":10,"convergence":0},
 "events":[
  {"accession":"0001628280-26-061401","date":"2026-09-08","type":"TAX_WITHHOLDING","shares":39959,"price":3.38,"value":135061.42,"remaining":1274282,"planned":0,"liq":"NON_LIQUIDITY","fact":"SEC Form 4 reports 39,959 shares disposed at $3.38 using transaction code F; Project A classifies this as tax/exercise-price withholding, not an open-market liquidity event.","url":"https://www.sec.gov/Archives/edgar/data/910638/000162828026061401/xslF345X06/wk-form4_1789074136.xml"}
 ]
}
]

with connect() as cx:
    cx.execute("DELETE FROM evidence"); cx.execute("DELETE FROM events"); cx.execute("DELETE FROM prospects")
    for r in records:
        cx.execute("""INSERT INTO prospects(id,person_name,role,company,issuer_cik,category,city,state,lat,lon,distance_miles,score,evidence_quality,advisor_relevance,primary_need,secondary_need,why_now,model_inference,tags_json,score_components_json,watchlisted)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (r["id"],r["person"],r["role"],r["company"],r["cik"],r["category"],r["city"],r["state"],r["lat"],r["lon"],r["distance"],r["score"],r["quality"],r["relevance"],r["primary"],r["secondary"],r["why"],r["inference"],json.dumps(r["tags"]),json.dumps(r["parts"]),1 if r["id"]==1 else 0))
        for e in r["events"]:
            cur=cx.execute("""INSERT INTO events(prospect_id,accession,form_type,event_date,event_type,shares,price,disclosed_value,remaining_shares,planned_transaction,liquidity_class,fact_summary,source_url)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(r["id"],e["accession"],"4",e["date"],e["type"],e["shares"],e["price"],e["value"],e["remaining"],e["planned"],e["liq"],e["fact"],e["url"]))
            eid=cur.lastrowid
            cx.execute("INSERT INTO evidence(prospect_id,event_id,label,assertion_class,summary,source_url) VALUES(?,?,?,?,?,?)",
              (r["id"],eid,"SEC FORM 4","VERIFIED PUBLIC FACT",e["fact"],e["url"]))
            if e["value"] is not None:
                cx.execute("INSERT INTO evidence(prospect_id,event_id,label,assertion_class,summary,source_url) VALUES(?,?,?,?,?,?)",
                  (r["id"],eid,"TRANSACTION VALUE","CALCULATED FROM VERIFIED FACT",
                   f"Displayed transaction value uses the filing's reported shares and price; it is not net worth or a brokerage balance.",e["url"]))
    cx.commit()
print("Seeded",len(records),"real prospect timelines and",sum(len(x["events"]) for x in records),"verified SEC events.")
