
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path
import json, subprocess, sys
from database import get_opportunities,get_opportunity,toggle_watchlist,health,DB

ROOT=Path(__file__).parent

def brief(x):
    themes=[x["primary_need"],x["secondary_need"]]
    missing=[
      "Confirm identity and source filing immediately before use",
      "Do not assume sale proceeds remain investable",
      "Do not infer outside account balances or total net worth"
    ]
    if any(e["planned_transaction"] for e in x["events"]):
        missing.append("Account for disclosed 10b5-1/planned-sale context in outreach prioritization")
    return {
      "why_now":x["why_now"],
      "planning_themes":[t for t in themes if t],
      "missing_diligence":missing,
      "next_research_action":"Open the retained primary SEC source, reconfirm the event and professional identity, then research only lawful professional contact context before any outreach."
    }

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        rel=urlparse(path).path.lstrip("/") or "index.html"
        return str(ROOT/rel)
    def json(self,obj,status=200):
        b=json.dumps(obj,indent=2).encode()
        self.send_response(status);self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/api/health":return self.json(health())
        if p=="/api/opportunities":return self.json(get_opportunities())
        if p.startswith("/api/opportunities/") and p.endswith("/brief"):
            try: pid=int(p.split("/")[3])
            except:return self.json({"error":"bad id"},400)
            x=get_opportunity(pid);return self.json(brief(x) if x else {"error":"not found"},200 if x else 404)
        if p.startswith("/api/opportunities/"):
            try: pid=int(p.rsplit("/",1)[-1])
            except:return self.json({"error":"bad id"},400)
            x=get_opportunity(pid);return self.json(x if x else {"error":"not found"},200 if x else 404)
        return super().do_GET()
    def do_POST(self):
        p=urlparse(self.path).path
        if p.startswith("/api/watchlist/"):
            try:pid=int(p.rsplit("/",1)[-1])
            except:return self.json({"error":"bad id"},400)
            v=toggle_watchlist(pid)
            return self.json({"watchlisted":v} if v is not None else {"error":"not found"},200 if v is not None else 404)
        return self.json({"error":"not found"},404)
    def log_message(self,fmt,*args):
        print("[Project A]",fmt%args)

if __name__=="__main__":
    if not DB.exists():
        subprocess.check_call([sys.executable,str(ROOT/"seed_real_data.py")])
    port=8787
    print(f"Project A running at http://127.0.0.1:{port}")
    ThreadingHTTPServer(("127.0.0.1",port),Handler).serve_forever()
