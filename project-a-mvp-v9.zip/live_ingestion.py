"""
Project A v6 — Live EDGAR ingestion runner

Runs the real discovery/fetch/parse/publish loop against SEC public endpoints.
No API key is required. Set PROJECT_A_USER_AGENT to identify your application:
  export PROJECT_A_USER_AGENT="Project A contact@example.com"

This implementation deliberately uses a conservative request interval, retries,
local caching, checkpointing, and exact accession deduplication.
"""
from __future__ import annotations
import json, os, re, time, urllib.request, urllib.error, urllib.parse
from pathlib import Path
from datetime import date, datetime, timedelta
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
CACHE = BASE / "cache"
CACHE.mkdir(exist_ok=True)
STATE = BASE / "ingestion_state.json"
RAW = BASE / "live_evidence.json"
PUBLISHED = BASE / "live_signals.json"

USER_AGENT = os.getenv("PROJECT_A_USER_AGENT", "Project-A-Prototype contact@example.com")
REQUEST_INTERVAL = float(os.getenv("PROJECT_A_REQUEST_INTERVAL", "0.20")) # 5 req/sec max by default
FORMS = {"4","4/A","SC 13D","SC 13D/A","SC 13G","SC 13G/A","8-K","8-K/A"}

_last_request = 0.0

def fetch(url, *, binary=False, retries=4):
    global _last_request
    key = re.sub(r"[^A-Za-z0-9._-]+","_",url)[-180:]
    cp = CACHE / key
    if cp.exists():
        b = cp.read_bytes()
        return b if binary else b.decode("utf-8","replace")
    for attempt in range(retries):
        wait = REQUEST_INTERVAL - (time.time()-_last_request)
        if wait > 0: time.sleep(wait)
        req = urllib.request.Request(url, headers={
            "User-Agent": USER_AGENT,
            "Accept-Encoding": "identity",
            "Host": urllib.parse.urlparse(url).netloc,
        })
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                b = r.read()
            _last_request = time.time()
            cp.write_bytes(b)
            return b if binary else b.decode("utf-8","replace")
        except urllib.error.HTTPError as e:
            _last_request = time.time()
            if e.code in (403,429,500,502,503,504) and attempt < retries-1:
                time.sleep(min(16, 2**attempt))
                continue
            raise

def load_state():
    if STATE.exists():
        return json.loads(STATE.read_text())
    return {"processed_accessions": [], "last_run": None}

def save_state(s):
    s["processed_accessions"] = s["processed_accessions"][-10000:]
    s["last_run"] = datetime.utcnow().isoformat()+"Z"
    STATE.write_text(json.dumps(s,indent=2))

def daily_master_url(d: date):
    q=(d.month-1)//3+1
    return f"https://www.sec.gov/Archives/edgar/daily-index/{d.year}/QTR{q}/master.{d:%Y%m%d}.idx"

def discover(days=3):
    rows=[]
    today=date.today()
    for i in range(days):
        d=today-timedelta(days=i)
        if d.weekday()>=5: continue
        try: txt=fetch(daily_master_url(d))
        except urllib.error.HTTPError as e:
            if e.code==404: continue
            raise
        start=False
        for line in txt.splitlines():
            if line.startswith("-----"): start=True; continue
            if not start or "|" not in line: continue
            parts=line.split("|")
            if len(parts)<5: continue
            cik,name,form,filed,filename=parts[:5]
            if form not in FORMS: continue
            accession=Path(filename).stem
            rows.append(dict(cik=cik,name=name,form=form,filed=filed,
                             filename=filename,accession=accession))
    return rows

def filing_dir_url(row):
    acc=row["accession"].replace("-","")
    return f"https://www.sec.gov/Archives/edgar/data/{int(row['cik'])}/{acc}/"

def filing_index_json(row):
    return json.loads(fetch(filing_dir_url(row)+"index.json"))

def choose_document(row, idx):
    items=idx.get("directory",{}).get("item",[])
    names=[x.get("name","") for x in items]
    # Ownership XML normally has ownershipDocument root; inspect XML candidates.
    if row["form"].startswith("4"):
        for n in names:
            if n.lower().endswith(".xml") and "xsl" not in n.lower():
                try:
                    t=fetch(filing_dir_url(row)+n)
                    if "<ownershipDocument" in t: return n,t
                except Exception: pass
    # For text-based schedules/8-K use primary HTML/text candidate.
    for n in names:
        low=n.lower()
        if low.endswith((".htm",".html",".txt")) and not low.startswith("index"):
            try: return n,fetch(filing_dir_url(row)+n)
            except Exception: pass
    return None,None

def val(node,path):
    x=node.find(path) if node is not None else None
    return x.text.strip() if x is not None and x.text else None

def num(x):
    try:return float(x)
    except:return None

def parse_form4(row, xml, docname):
    root=ET.fromstring(xml)
    issuer=root.find(".//issuer")
    owner=root.find(".//reportingOwner")
    foot=" ".join((x.text or "") for x in root.findall(".//footnote"))
    remarks=val(root,".//remarks") or ""
    person=val(owner,".//rptOwnerName")
    title=val(owner,".//reportingOwnerRelationship/officerTitle")
    events=[]
    for t in root.findall(".//nonDerivativeTransaction"):
        code=val(t,".//transactionCoding/transactionCode")
        ad=val(t,".//transactionAmounts/transactionAcquiredDisposedCode/value")
        shares=num(val(t,".//transactionAmounts/transactionShares/value"))
        price=num(val(t,".//transactionAmounts/transactionPricePerShare/value"))
        after=num(val(t,".//postTransactionAmounts/sharesOwnedFollowingTransaction/value"))
        if code!="S" or ad!="D": continue
        value=shares*price if shares is not None and price is not None else None
        events.append({
          "source_type":"FORM4","source_url":filing_dir_url(row)+docname,
          "filed_date":row["filed"],"entity_name":val(issuer,".//issuerName") or row["name"],
          "person_name":person,"cik":val(issuer,".//issuerCik") or row["cik"],
          "event_type":"insider-sale","disclosed_value":value,"shares":shares,
          "remaining_shares":after,"planned_transaction":"10b5-1" in (foot+" "+remarks).lower(),
          "primary_source":True,"raw_id":row["accession"],
          "fact_summary":f"SEC Form 4 reports disposition of {shares:g} shares"+(f" at ${price:,.2f}/share." if price is not None else "."),
          "role":title
        })
    return events

def parse_text_event(row,text,docname):
    clean=re.sub(r"<[^>]+>"," ",text)
    clean=re.sub(r"\s+"," ",clean)
    st="OTHER_PRIMARY"; et="filing-event"; summary=f"SEC {row['form']} filed by {row['name']}."
    if row["form"].startswith("SC 13D"): st="SCHEDULE13D"; et="beneficial-ownership"
    elif row["form"].startswith("SC 13G"): st="SCHEDULE13G"; et="beneficial-ownership"
    elif row["form"].startswith("8-K"):
        # Only elevate 8-K when Item 2.01 appears; otherwise retain as low-level event.
        if re.search(r"Item\s+2\.01",clean,re.I):
            st="FORM8K_MA"; et="acquisition-disposition"
            summary=f"SEC 8-K contains Item 2.01 acquisition/disposition disclosure for {row['name']}."
        else:
            st="OTHER_PRIMARY"; et="8-k-other"
    return [{
      "source_type":st,"source_url":filing_dir_url(row)+docname,
      "filed_date":row["filed"],"entity_name":row["name"],"person_name":None,
      "cik":row["cik"],"event_type":et,"disclosed_value":None,"shares":None,
      "remaining_shares":None,"planned_transaction":False,"primary_source":True,
      "raw_id":row["accession"],"fact_summary":summary
    }]

def normalize_for_convergence(x):
    from convergence_engine import Evidence
    return Evidence(
      source_type=x["source_type"],source_url=x["source_url"],filed_date=x["filed_date"],
      entity_name=x["entity_name"],person_name=x.get("person_name"),cik=x.get("cik"),
      event_type=x.get("event_type",""),disclosed_value=x.get("disclosed_value"),
      shares=x.get("shares"),primary_source=x.get("primary_source",True),
      planned_transaction=x.get("planned_transaction",False),
      fact_summary=x.get("fact_summary",""),raw_id=x.get("raw_id")
    )

def run(days=3, max_filings=250):
    from convergence_engine import converge
    state=load_state()
    processed=set(state["processed_accessions"])
    evidence=json.loads(RAW.read_text()) if RAW.exists() else []
    rows=discover(days)
    new=0; errors=[]
    for row in rows:
        if new>=max_filings: break
        if row["accession"] in processed: continue
        try:
            idx=filing_index_json(row)
            doc,text=choose_document(row,idx)
            if not doc or not text:
                processed.add(row["accession"]); continue
            ev=parse_form4(row,text,doc) if row["form"].startswith("4") else parse_text_event(row,text,doc)
            evidence.extend(ev)
            processed.add(row["accession"]); new+=1
        except Exception as e:
            errors.append({"accession":row["accession"],"error":repr(e)})
    # global exact accession/source/event dedupe
    dedup={}
    for e in evidence:
        k=(e.get("raw_id"),e.get("source_type"),e.get("event_type"),e.get("person_name"))
        dedup[str(k)]=e
    evidence=list(dedup.values())
    RAW.write_text(json.dumps(evidence,indent=2))
    live=converge([normalize_for_convergence(x) for x in evidence])
    PUBLISHED.write_text(json.dumps(live,indent=2))
    state["processed_accessions"]=list(processed)
    state["last_errors"]=errors[-25:]
    save_state(state)
    return {"discovered":len(rows),"new_filings_processed":new,
            "evidence_items":len(evidence),"published_opportunities":len(live),
            "errors":len(errors),"output":str(PUBLISHED)}

if __name__=="__main__":
    print(json.dumps(run(),indent=2))
